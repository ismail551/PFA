import { Component } from '@angular/core';

@Component({
  selector: 'app-tableview',
  standalone: true,
  imports: [],
  templateUrl: './tableview.component.html',
  styleUrl: './tableview.component.css'
})
export class TableviewComponent {

}
